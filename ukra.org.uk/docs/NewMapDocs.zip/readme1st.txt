README FILE FOR JULY 2020 BRONZE MAP RELEASE

This bundle contains the following:
1. This file
2. Guidance document, MAPBGuide - Read this next
3. A MAP Glossary - Check for the terms MAP uses
4. Record form - A place to record the tasks for the Bronze Award
5. Requirements document - The exact tasks required.  

Note: File naming has changed slightly to make things a little more readable.
The Reference ID's for the documents all begin with MAP in capital letters.  
The number at the end of the file name is the version.

Michael Williams, Chair UKRA 25th July 2020